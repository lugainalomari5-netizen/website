<?php
$db = mysqli_connect("localhost", "root", "hala/123"); 
mysqli_select_db($db, "clinic__info");

if (!$db) { die("Connection failed"); }

$message = "";
$status = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['fullname'];
    $email     = $_POST['email'];
    $user_name = $_POST['username'];
    $password  = $_POST['password'];

    $q = "INSERT INTO patient (Fullname, Email, Username, Password) 
          VALUES ('$full_name', '$email', '$user_name', '$password')";

    if (mysqli_query($db, $q)) {
        $message = "أهلاً بك يا $full_name، تم إنشاء حسابك الطبي بنجاح!";
        $status = "success";
    } else {
        $message = "عذراً، حدث خطأ أثناء التسجيل: " . mysqli_error($db);
        $status = "error";
    }
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>تأكيد التسجيل | عيادة المتكاملة</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body { display: flex; justify-content: center; align-items: center; height: 100vh; }
        .card-box { text-align: center; max-width: 500px; }
        .icon { font-size: 50px; margin-bottom: 20px; display: block; }
        .card-box { border-top-color: <?php echo ($status == 'success') ? '#2196F3' : '#f44336'; ?>; }
    </style>
</head>
<body>
    <div class="card-box">
        <span class="icon"><?php echo ($status == 'success') ? '💙' : '⚠️'; ?></span>
        <h2><?php echo ($status == 'success') ? 'تم التسجيل بنجاح' : 'خطأ في العملية'; ?></h2>
        <p style="margin-bottom: 30px; color: #486581;"><?php echo $message; ?></p>
        
        <a href="book.html" class="btn-main">انتقل لتسجيل الدخول</a>
    </div>
</body>
</html>
<?php mysqli_close($db); ?>