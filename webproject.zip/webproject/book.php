<?php

$db = mysqli_connect("localhost", "root", "hala/123");
mysqli_select_db($db, "clinic__info");
$_username = $_POST['username'];
$_password = $_POST['password'];
$q = "SELECT * FROM patient WHERE Username = '$_username' AND Password = '$_password'";
$r = mysqli_query($db, $q);

if ($row = mysqli_fetch_row($r)) {
    $fullname = $row[0];
    $email = $row[1];
    $appointment = $row[4] ? $row[4] : "لم يتم حجز موعد بعد";
?>
<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>الملف الطبي | عيادة المتكاملة</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .container { max-width: 1000px; margin: 40px auto; padding: 20px; }
        .logout-link { color: #f44336; border: 1px solid #f44336; padding: 5px 15px; border-radius: 5px; text-decoration: none; }
        .logout-link:hover { background: #f44336; color: #fff; }

        /* Welcome Box */
        .welcome-box {
            background: linear-gradient(to right, #2196F3, #1976D2); color: white;
            padding: 30px; border-radius: 15px; margin-bottom: 30px;
        }
        .info-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }
        
        /* Card Tweaks */
        .card { background: #fff; padding: 25px; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); border-top: 5px solid #2196F3; }
        .appointment-status { background: #e3f2fd; padding: 15px; border-radius: 10px; color: #0d47a1; font-weight: 700; text-align: center; margin-top: 10px; }
        
        .btn-delete { background: #fff; color: #f44336; border: 1px solid #f44336; width:100%; margin-top:10px; }
        .btn-delete:hover { background: #f44336; color: white; }
    </style>
</head>
<body>
    <header class="medical-header">
        <div class="logo">Al Mtkamla Clinic</div>
        <a href="main.html" class="logout-link">تسجيل الخروج</a>
    </header>

    <div class="container">
        <div class="welcome-box">
            <h1>أهلاً بك، <?php echo $fullname; ?></h1>
            <p>يمكنك مراجعة بياناتك الطبية وإدارة مواعيدك من هنا.</p>
        </div>

        <div class="info-grid">
            <div class="card">
                <h3>معلومات المريض</h3>
                <p><strong>البريد:</strong> <?php echo $email; ?></p>
                <div class="appointment-status"><?php echo $appointment; ?></div>
            </div>

            <div class="card">
                <h3>تحديث الموعد</h3>
                <form method="post" action="appointment.php">
                    <input type="text" name="select" placeholder="الموعد الجديد" required>
                    <input type="hidden" name="password" value="<?php echo $_password; ?>">
                    <button type="submit" class="btn-main">حجز الموعد</button>
                </form>
            </div>

            <div class="card" style="border-top-color: #f44336;">
                <h3>حذف الملف</h3>
                <form method="post" action="delete.php">
                    <input type="hidden" name="username" value="<?php echo $_username; ?>">
                    <input type="hidden" name="password" value="<?php echo $_password; ?>">
                    <button type="submit" class="btn-delete" onclick="return confirm('تأكيد الحذف؟')">إلغاء الحساب</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
<?php
} else {
    print("<script>alert('بيانات خاطئة'); window.location.href='book.html';</script>");
}
mysqli_close($db);
?>