<?php
$db = mysqli_connect("localhost", "root", "hala/123");
mysqli_select_db($db, "clinic__info");

$message = "";
$status = "";

if (isset($_POST['username']) && isset($_POST['password'])) {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    $q = "DELETE FROM patient WHERE Username='$user' AND Password='$pass'";

    if (mysqli_query($db, $q)) {
        if (mysqli_affected_rows($db) > 0) {
            $message = "تم حذف ملفك الطبي من نظامنا بنجاح. نتمنى لك دوام الصحة.";
            $status = "deleted";
        } else {
            $message = "لم يتم العثور على الحساب، أو أن البيانات المدخلة غير صحيحة.";
            $status = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>حذف الحساب | عيادة المتكاملة</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body { display: flex; justify-content: center; align-items: center; height: 100vh; }
        .card-box { text-align: center; max-width: 500px; border-top-color: #f44336; /* أحمر للحذف */ }
        .icon { font-size: 50px; display: block; margin-bottom: 20px; }
        h2 { color: #d32f2f; }
        
        .btn-home { 
            display: inline-block; padding: 12px 30px; 
            background-color: #486581; color: white; 
            text-decoration: none; border-radius: 8px; font-weight: 700; width: 100%;
        }
        .btn-home:hover { background-color: #334e68; }
    </style>
</head>
<body>
    <div class="card-box">
        <span class="icon">🗑️</span>
        <h2><?php echo ($status == 'deleted') ? 'تم حذف الملف' : 'فشل الحذف'; ?></h2>
        <p style="margin-bottom: 30px; color: #486581;"><?php echo $message; ?></p>
        
        <a href="main.html" class="btn-home">العودة للرئيسية</a>
    </div>
</body>
</html>
<?php mysqli_close($db); ?>