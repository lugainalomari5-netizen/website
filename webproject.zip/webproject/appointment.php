<?php 
$db = mysqli_connect("localhost", "root", "hala/123");
mysqli_select_db($db, "clinic__info");

$message = "";
$status_class = "";

if (isset($_POST["select"]) && isset($_POST["password"])) {
    $selectt = $_POST["select"];
    $password = $_POST["password"];
    $q = "UPDATE patient SET Appointment='$selectt' WHERE Password='$password'";

    if (mysqli_query($db, $q)) {
        if (mysqli_affected_rows($db) > 0) {
            $message = "تم تحديث موعدك بنجاح!";
            $status_class = "success";
        } else {
            $message = "حدث خطأ! تأكد من صحة البيانات.";
            $status_class = "error";
        }
    } else {
        $message = "خطأ: " . mysqli_error($db);
        $status_class = "error";
    }
} 
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>تأكيد الحجز</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body { display: flex; justify-content: center; align-items: center; height: 100vh; }
        .confirmation-card {
            background: white; padding: 40px; border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1); text-align: center;
            max-width: 500px; width: 90%;
            border-top: 8px solid <?php echo ($status_class == 'success') ? '#2196F3' : '#f44336'; ?>;
        }
        .icon { font-size: 60px; margin-bottom: 20px; display: block; }
        h2 { color: #102a43; margin-bottom: 15px; }
        p { color: #486581; margin-bottom: 30px; line-height: 1.6; }
        .btn-back {
            display: inline-block; padding: 12px 30px; background-color: #2196F3;
            color: white; text-decoration: none; border-radius: 10px; font-weight: 700;
        }
        .btn-back:hover { background-color: #1565c0; }
        .success-icon { color: #2ecc71; }
        .error-icon { color: #f44336; }
    </style>
</head>
<body>
    <div class="confirmation-card">
        <?php if ($status_class == "success"): ?>
            <span class="icon success-icon">✔</span>
            <h2>عملية ناجحة</h2>
        <?php else: ?>
            <span class="icon error-icon">✖</span>
            <h2>فشل الإجراء</h2>
        <?php endif; ?>
        <p><?php echo $message; ?></p>
        <a href="javascript:history.back()" class="btn-back">العودة للملف الشخصي</a>
    </div>
</body>
</html>
<?php mysqli_close($db); ?>